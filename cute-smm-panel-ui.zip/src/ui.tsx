import React from "react";

export const cx = (...c: (string | false | undefined)[]) => c.filter(Boolean).join(" ");

export function Card({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cx(
        "rounded-3xl border border-white/70 bg-white/80 p-5 shadow-[0_10px_40px_-12px_rgba(236,72,153,0.28)] backdrop-blur-xl",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function Button({
  children,
  onClick,
  type = "button",
  variant = "primary",
  disabled,
  className = "",
}: {
  children: React.ReactNode;
  onClick?: () => void;
  type?: "button" | "submit";
  variant?: "primary" | "ghost" | "soft";
  disabled?: boolean;
  className?: string;
}) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-2xl px-5 py-2.5 text-sm font-semibold transition active:scale-[.97] disabled:opacity-50 disabled:active:scale-100";
  const styles = {
    primary:
      "bg-gradient-to-r from-fuchsia-500 via-pink-500 to-rose-400 text-white shadow-lg shadow-pink-300/50 hover:brightness-110",
    soft: "bg-pink-100 text-pink-700 hover:bg-pink-200",
    ghost: "text-slate-500 hover:bg-white hover:text-pink-600",
  }[variant];
  return (
    <button type={type} onClick={onClick} disabled={disabled} className={cx(base, styles, className)}>
      {children}
    </button>
  );
}

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block space-y-1.5">
      <span className="text-xs font-bold uppercase tracking-wider text-slate-500">{label}</span>
      {children}
      {hint && <span className="block text-xs text-slate-400">{hint}</span>}
    </label>
  );
}

export const inputCls =
  "w-full rounded-2xl border border-pink-100 bg-white/90 px-4 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-300 focus:border-pink-300 focus:ring-4 focus:ring-pink-100";

export function Badge({ children, tone = "pink" }: { children: React.ReactNode; tone?: string }) {
  const tones: Record<string, string> = {
    pink: "bg-pink-100 text-pink-700",
    violet: "bg-violet-100 text-violet-700",
    green: "bg-emerald-100 text-emerald-700",
    amber: "bg-amber-100 text-amber-700",
    slate: "bg-slate-100 text-slate-600",
  };
  return (
    <span className={cx("rounded-full px-2.5 py-1 text-[11px] font-bold", tones[tone] || tones.pink)}>
      {children}
    </span>
  );
}

export function Toast({ msg, tone }: { msg: string; tone: "ok" | "err" }) {
  return (
    <div
      className={cx(
        "fixed bottom-6 left-1/2 z-50 -translate-x-1/2 animate-[pop_.3s_ease] rounded-2xl px-5 py-3 text-sm font-semibold text-white shadow-xl",
        tone === "ok" ? "bg-emerald-500" : "bg-rose-500",
      )}
    >
      {msg}
    </div>
  );
}
