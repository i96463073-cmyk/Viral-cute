import { useEffect, useMemo, useState } from "react";
import {
  ApiConfig,
  Order,
  Service,
  api,
  demoServices,
  loadConfig,
  loadOrders,
  saveConfig,
  saveOrders,
} from "./api";
import { Badge, Button, Card, Field, Toast, cx, inputCls } from "./ui";

type View = "dashboard" | "new" | "services" | "orders" | "settings";

const NAV: { id: View; label: string; icon: string }[] = [
  { id: "dashboard", label: "Dashboard", icon: "🏠" },
  { id: "new", label: "New Order", icon: "🛍️" },
  { id: "services", label: "Services", icon: "🎀" },
  { id: "orders", label: "My Orders", icon: "📦" },
  { id: "settings", label: "API Settings", icon: "⚙️" },
];

const CAT_EMOJI: Record<string, string> = {
  Instagram: "📸",
  TikTok: "🎵",
  YouTube: "▶️",
  "Twitter / X": "🐦",
  Telegram: "💌",
  Spotify: "🎧",
  Facebook: "👍",
};

export default function App() {
  const [view, setView] = useState<View>("dashboard");
  const [cfg, setCfg] = useState<ApiConfig>(loadConfig());
  const [services, setServices] = useState<Service[]>(demoServices);
  const [live, setLive] = useState(false);
  const [loading, setLoading] = useState(false);
  const [balance, setBalance] = useState<{ balance: string; currency: string } | null>(null);
  const [orders, setOrders] = useState<Order[]>(loadOrders());
  const [toast, setToast] = useState<{ msg: string; tone: "ok" | "err" } | null>(null);
  const [preselect, setPreselect] = useState<string | number | null>(null);
  const [navOpen, setNavOpen] = useState(false);

  const notify = (msg: string, tone: "ok" | "err" = "ok") => {
    setToast({ msg, tone });
    setTimeout(() => setToast(null), 2800);
  };

  useEffect(() => saveOrders(orders), [orders]);

  async function refresh(silent = false) {
    if (!cfg.endpoint) {
      setServices(demoServices);
      setLive(false);
      if (!silent) notify("Demo mode — add your provider API in Settings", "err");
      return;
    }
    setLoading(true);
    try {
      const [s, b] = await Promise.all([
        api.services(cfg),
        api.balance(cfg).catch(() => null),
      ]);
      if (Array.isArray(s) && s.length) {
        setServices(s);
        setLive(true);
      }
      if (b) setBalance(b);
      if (!silent) notify("Connected to provider 💖");
    } catch (e: any) {
      setLive(false);
      notify(e.message || "Connection failed", "err");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (cfg.endpoint) refresh(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const categories = useMemo(
    () => Array.from(new Set(services.map((s) => s.category))),
    [services],
  );

  return (
    <div className="min-h-screen bg-[radial-gradient(1200px_600px_at_10%_-10%,#ffe4f3,transparent),radial-gradient(900px_500px_at_100%_0%,#e0e7ff,transparent)] bg-rose-50/60 text-slate-800">
      <style>{`@keyframes pop{from{opacity:0;transform:translate(-50%,12px)}to{opacity:1;transform:translate(-50%,0)}}
      @keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}`}</style>

      <div className="mx-auto flex max-w-7xl gap-6 p-4 lg:p-6">
        {/* Sidebar */}
        <aside
          className={cx(
            "fixed inset-y-0 left-0 z-40 w-64 shrink-0 transform bg-white/90 p-5 backdrop-blur-xl transition lg:static lg:block lg:rounded-3xl lg:bg-white/70",
            navOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
          )}
        >
          <div className="mb-8 flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-fuchsia-500 to-rose-400 text-xl shadow-lg shadow-pink-300/60">
              💗
            </div>
            <div>
              <div className="text-lg font-black leading-none tracking-tight">
                Viral<span className="text-pink-500">Cute</span>
              </div>
              <div className="text-[11px] font-semibold text-slate-400">smm panel</div>
            </div>
          </div>
          <nav className="space-y-1.5">
            {NAV.map((n) => (
              <button
                key={n.id}
                onClick={() => {
                  setView(n.id);
                  setNavOpen(false);
                }}
                className={cx(
                  "flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold transition",
                  view === n.id
                    ? "bg-gradient-to-r from-fuchsia-500 to-rose-400 text-white shadow-lg shadow-pink-300/50"
                    : "text-slate-500 hover:bg-pink-50 hover:text-pink-600",
                )}
              >
                <span>{n.icon}</span>
                {n.label}
              </button>
            ))}
          </nav>

          <div className="mt-8 rounded-3xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-rose-400 p-4 text-white">
            <div className="text-2xl" style={{ animation: "float 3s ease-in-out infinite" }}>
              🌸
            </div>
            <p className="mt-2 text-sm font-bold">Go viral today!</p>
            <p className="text-xs text-white/80">
              Cheapest rates, instant delivery, 24/7 cute support.
            </p>
          </div>
        </aside>
        {navOpen && (
          <div className="fixed inset-0 z-30 bg-black/20 lg:hidden" onClick={() => setNavOpen(false)} />
        )}

        {/* Main */}
        <main className="min-w-0 flex-1 space-y-6">
          <header className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button
                className="grid h-10 w-10 place-items-center rounded-2xl bg-white shadow lg:hidden"
                onClick={() => setNavOpen(true)}
              >
                ☰
              </button>
              <div>
                <h1 className="text-2xl font-black tracking-tight capitalize">
                  {NAV.find((n) => n.id === view)?.label}
                </h1>
                <p className="text-sm text-slate-400">
                  {live ? "Live provider connected" : "Demo data — connect your API"}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="rounded-2xl bg-white/80 px-4 py-2 text-sm shadow">
                <span className="text-slate-400">Balance </span>
                <span className="font-black text-pink-600">
                  {balance ? `${balance.balance} ${balance.currency}` : "—"}
                </span>
              </div>
              <Button variant="soft" onClick={() => refresh()}>
                {loading ? "Syncing…" : "↻ Sync"}
              </Button>
            </div>
          </header>

          {view === "dashboard" && (
            <Dashboard
              services={services}
              orders={orders}
              categories={categories}
              go={setView}
              live={live}
            />
          )}
          {view === "new" && (
            <NewOrder
              cfg={cfg}
              services={services}
              live={live}
              preselect={preselect}
              onDone={(o) => {
                setOrders([o, ...orders]);
                setPreselect(null);
                setView("orders");
                notify(`Order #${o.id} placed! 🎉`);
              }}
              onError={(m) => notify(m, "err")}
            />
          )}
          {view === "services" && (
            <Services
              services={services}
              onOrder={(id) => {
                setPreselect(id);
                setView("new");
              }}
            />
          )}
          {view === "orders" && (
            <Orders
              orders={orders}
              cfg={cfg}
              live={live}
              onUpdate={setOrders}
              notify={notify}
            />
          )}
          {view === "settings" && (
            <Settings
              cfg={cfg}
              onSave={(c) => {
                setCfg(c);
                saveConfig(c);
                notify("API settings saved 💾");
              }}
              onTest={refresh}
              loading={loading}
            />
          )}

          <footer className="pb-6 pt-2 text-center text-xs text-slate-400">
            Made with 💖 by ViralCute — bring your own provider API.
          </footer>
        </main>
      </div>
      {toast && <Toast msg={toast.msg} tone={toast.tone} />}
    </div>
  );
}

/* ----------------------------- Dashboard ----------------------------- */
function Dashboard({
  services,
  orders,
  categories,
  go,
  live,
}: {
  services: Service[];
  orders: Order[];
  categories: string[];
  go: (v: View) => void;
  live: boolean;
}) {
  const spent = orders.reduce((a, o) => a + Number(o.charge || 0), 0);
  const stats = [
    { label: "Services", value: services.length, icon: "🎀", tone: "from-pink-400 to-rose-400" },
    { label: "Orders", value: orders.length, icon: "📦", tone: "from-violet-400 to-fuchsia-400" },
    { label: "Spent", value: `$${spent.toFixed(2)}`, icon: "💸", tone: "from-amber-300 to-orange-400" },
    { label: "Platforms", value: categories.length, icon: "🌍", tone: "from-sky-400 to-indigo-400" },
  ];
  return (
    <div className="space-y-6">
      <Card className="relative overflow-hidden !p-0">
        <div className="bg-gradient-to-r from-fuchsia-500 via-pink-500 to-rose-400 p-8 text-white">
          <Badge tone="slate">{live ? "🟢 Live API" : "🌸 Demo mode"}</Badge>
          <h2 className="mt-3 text-3xl font-black leading-tight md:text-4xl">
            Grow cute. Grow fast. <br /> Go viral ✨
          </h2>
          <p className="mt-2 max-w-lg text-white/85">
            Followers, likes, views & more — delivered instantly from your connected provider.
          </p>
          <div className="mt-5 flex gap-3">
            <button
              onClick={() => go("new")}
              className="rounded-2xl bg-white px-6 py-3 text-sm font-black text-pink-600 shadow-lg transition hover:scale-[1.03]"
            >
              🛍️ Place an order
            </button>
            <button
              onClick={() => go("services")}
              className="rounded-2xl border border-white/60 px-6 py-3 text-sm font-bold text-white transition hover:bg-white/15"
            >
              Browse services
            </button>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label} className="!p-4">
            <div
              className={cx(
                "mb-3 grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br text-lg",
                s.tone,
              )}
            >
              {s.icon}
            </div>
            <div className="text-2xl font-black">{s.value}</div>
            <div className="text-xs font-semibold uppercase tracking-wide text-slate-400">
              {s.label}
            </div>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        {categories.slice(0, 6).map((c) => {
          const list = services.filter((s) => s.category === c);
          const cheapest = Math.min(...list.map((s) => Number(s.rate) || 0));
          return (
            <Card key={c} className="transition hover:-translate-y-1">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{CAT_EMOJI[c] || "✨"}</span>
                  <div>
                    <div className="font-bold">{c}</div>
                    <div className="text-xs text-slate-400">{list.length} services</div>
                  </div>
                </div>
                <Badge>from ${cheapest.toFixed(2)}</Badge>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

/* ----------------------------- New Order ----------------------------- */
function NewOrder({
  cfg,
  services,
  live,
  preselect,
  onDone,
  onError,
}: {
  cfg: ApiConfig;
  services: Service[];
  live: boolean;
  preselect: string | number | null;
  onDone: (o: Order) => void;
  onError: (m: string) => void;
}) {
  const categories = useMemo(
    () => Array.from(new Set(services.map((s) => s.category))),
    [services],
  );
  const initial = preselect ? services.find((s) => String(s.service) === String(preselect)) : null;
  const [cat, setCat] = useState(initial?.category || categories[0] || "");
  const [sid, setSid] = useState<string>(String(initial?.service ?? ""));
  const [link, setLink] = useState("");
  const [qty, setQty] = useState<number>(0);
  const [busy, setBusy] = useState(false);

  const inCat = services.filter((s) => s.category === cat);
  const svc = services.find((s) => String(s.service) === sid) || inCat[0];

  useEffect(() => {
    if (!inCat.some((s) => String(s.service) === sid)) setSid(String(inCat[0]?.service ?? ""));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cat]);

  useEffect(() => {
    if (svc && !qty) setQty(Number(svc.min));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sid]);

  const charge = svc ? (Number(svc.rate) * qty) / 1000 : 0;

  async function submit() {
    if (!svc) return;
    if (!link.trim()) return onError("Please paste your link 🔗");
    if (qty < Number(svc.min) || qty > Number(svc.max))
      return onError(`Quantity must be ${svc.min} – ${svc.max}`);
    setBusy(true);
    try {
      let id = String(Math.floor(Math.random() * 900000) + 100000);
      if (live) {
        const r = await api.addOrder(cfg, { service: svc.service, link, quantity: qty });
        id = String(r.order);
      }
      onDone({
        id,
        service: svc.name,
        link,
        quantity: qty,
        charge: charge.toFixed(4),
        status: live ? "Pending" : "Demo",
        created: Date.now(),
      });
      setLink("");
    } catch (e: any) {
      onError(e.message || "Order failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <Card className="lg:col-span-2">
        <div className="space-y-4">
          <Field label="Category">
            <select className={inputCls} value={cat} onChange={(e) => setCat(e.target.value)}>
              {categories.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </Field>
          <Field label="Service">
            <select className={inputCls} value={sid} onChange={(e) => setSid(e.target.value)}>
              {inCat.map((s) => (
                <option key={s.service} value={String(s.service)}>
                  {s.name} — ${Number(s.rate).toFixed(2)}/1k
                </option>
              ))}
            </select>
          </Field>
          <Field label="Link" hint="Profile, post or video URL">
            <input
              className={inputCls}
              placeholder="https://instagram.com/yourprofile"
              value={link}
              onChange={(e) => setLink(e.target.value)}
            />
          </Field>
          <Field label="Quantity" hint={svc ? `Min ${svc.min} · Max ${svc.max}` : ""}>
            <input
              type="number"
              className={inputCls}
              value={qty}
              onChange={(e) => setQty(Number(e.target.value))}
            />
          </Field>
          {svc && (
            <input
              type="range"
              min={Number(svc.min)}
              max={Math.min(Number(svc.max), 100000)}
              value={qty}
              onChange={(e) => setQty(Number(e.target.value))}
              className="w-full accent-pink-500"
            />
          )}
          <Button onClick={submit} disabled={busy} className="w-full !py-3">
            {busy ? "Placing…" : `💖 Place order · $${charge.toFixed(3)}`}
          </Button>
        </div>
      </Card>

      <Card className="h-fit">
        <h3 className="mb-3 text-sm font-black uppercase tracking-wide text-slate-400">Summary</h3>
        <div className="space-y-3 text-sm">
          <Row k="Service" v={svc?.name || "—"} />
          <Row k="Rate / 1000" v={svc ? `$${Number(svc.rate).toFixed(2)}` : "—"} />
          <Row k="Quantity" v={qty.toLocaleString()} />
          <Row k="Refill" v={svc?.refill ? "✅ Yes" : "—"} />
          <div className="my-3 border-t border-dashed border-pink-200" />
          <div className="flex items-center justify-between">
            <span className="font-bold">Total</span>
            <span className="text-2xl font-black text-pink-600">${charge.toFixed(3)}</span>
          </div>
        </div>
        <p className="mt-4 rounded-2xl bg-pink-50 p-3 text-xs text-pink-600">
          {live
            ? "Orders are sent straight to your provider API."
            : "Demo mode: orders are saved locally only."}
        </p>
      </Card>
    </div>
  );
}

const Row = ({ k, v }: { k: string; v: string }) => (
  <div className="flex items-start justify-between gap-4">
    <span className="text-slate-400">{k}</span>
    <span className="max-w-[60%] text-right font-semibold">{v}</span>
  </div>
);

/* ----------------------------- Services ----------------------------- */
function Services({
  services,
  onOrder,
}: {
  services: Service[];
  onOrder: (id: string | number) => void;
}) {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const cats = ["All", ...Array.from(new Set(services.map((s) => s.category)))];
  const list = services.filter(
    (s) =>
      (cat === "All" || s.category === cat) && s.name.toLowerCase().includes(q.toLowerCase()),
  );
  return (
    <div className="space-y-4">
      <Card className="!p-4">
        <input
          className={inputCls}
          placeholder="🔍 Search services…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <div className="mt-3 flex flex-wrap gap-2">
          {cats.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={cx(
                "rounded-full px-4 py-1.5 text-xs font-bold transition",
                cat === c
                  ? "bg-gradient-to-r from-fuchsia-500 to-rose-400 text-white shadow"
                  : "bg-pink-50 text-slate-500 hover:bg-pink-100",
              )}
            >
              {CAT_EMOJI[c] || (c === "All" ? "✨" : "•")} {c}
            </button>
          ))}
        </div>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {list.map((s) => (
          <Card key={String(s.service)} className="flex flex-col justify-between transition hover:-translate-y-1">
            <div>
              <div className="mb-2 flex items-center justify-between">
                <Badge tone="violet">#{s.service}</Badge>
                {s.refill && <Badge tone="green">♻️ Refill</Badge>}
              </div>
              <h3 className="font-bold leading-snug">{s.name}</h3>
              <p className="mt-1 text-xs text-slate-400">
                Min {s.min} · Max {s.max}
              </p>
            </div>
            <div className="mt-4 flex items-center justify-between">
              <div>
                <div className="text-xl font-black text-pink-600">
                  ${Number(s.rate).toFixed(2)}
                </div>
                <div className="text-[11px] text-slate-400">per 1000</div>
              </div>
              <Button variant="soft" onClick={() => onOrder(s.service)}>
                Order →
              </Button>
            </div>
          </Card>
        ))}
        {!list.length && (
          <Card className="md:col-span-2 xl:col-span-3 text-center text-slate-400">
            No services found 🥺
          </Card>
        )}
      </div>
    </div>
  );
}

/* ----------------------------- Orders ----------------------------- */
function Orders({
  orders,
  cfg,
  live,
  onUpdate,
  notify,
}: {
  orders: Order[];
  cfg: ApiConfig;
  live: boolean;
  onUpdate: (o: Order[]) => void;
  notify: (m: string, t?: "ok" | "err") => void;
}) {
  async function check(o: Order) {
    if (!live) return notify("Connect your API to refresh status", "err");
    try {
      const r = await api.status(cfg, o.id);
      onUpdate(
        orders.map((x) =>
          x.id === o.id
            ? { ...x, status: r.status || x.status, remains: r.remains, start_count: r.start_count }
            : x,
        ),
      );
      notify("Status updated ✨");
    } catch (e: any) {
      notify(e.message, "err");
    }
  }
  const tone = (s: string) =>
    /complete/i.test(s) ? "green" : /progress|pending/i.test(s) ? "amber" : "slate";

  if (!orders.length)
    return (
      <Card className="py-16 text-center">
        <div className="text-5xl">🫧</div>
        <p className="mt-3 font-bold">No orders yet</p>
        <p className="text-sm text-slate-400">Place your first order and watch it go viral!</p>
      </Card>
    );

  return (
    <Card className="!p-0 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-pink-50/70 text-xs uppercase tracking-wide text-slate-500">
            <tr>
              {["ID", "Service", "Link", "Qty", "Charge", "Status", ""].map((h) => (
                <th key={h} className="px-4 py-3 font-bold">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id} className="border-t border-pink-50 hover:bg-pink-50/40">
                <td className="px-4 py-3 font-black text-pink-600">#{o.id}</td>
                <td className="max-w-[220px] truncate px-4 py-3">{o.service}</td>
                <td className="max-w-[160px] truncate px-4 py-3 text-slate-400">{o.link}</td>
                <td className="px-4 py-3">{o.quantity.toLocaleString()}</td>
                <td className="px-4 py-3">${Number(o.charge).toFixed(3)}</td>
                <td className="px-4 py-3">
                  <Badge tone={tone(o.status)}>{o.status}</Badge>
                </td>
                <td className="px-4 py-3">
                  <Button variant="ghost" onClick={() => check(o)}>
                    ↻
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

/* ----------------------------- Settings ----------------------------- */
function Settings({
  cfg,
  onSave,
  onTest,
  loading,
}: {
  cfg: ApiConfig;
  onSave: (c: ApiConfig) => void;
  onTest: () => void;
  loading: boolean;
}) {
  const [f, setF] = useState<ApiConfig>(cfg);
  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <Card className="lg:col-span-2 space-y-4">
        <Field label="API Endpoint" hint="Usually https://yourprovider.com/api/v2">
          <input
            className={inputCls}
            placeholder="https://provider.com/api/v2"
            value={f.endpoint}
            onChange={(e) => setF({ ...f, endpoint: e.target.value })}
          />
        </Field>
        <Field label="API Key" hint="Found in your provider account page">
          <input
            type="password"
            className={inputCls}
            placeholder="••••••••••••••••"
            value={f.apiKey}
            onChange={(e) => setF({ ...f, apiKey: e.target.value })}
          />
        </Field>
        <Field
          label="CORS Proxy (optional)"
          hint="If the provider blocks browser requests, prefix e.g. https://corsproxy.io/?"
        >
          <input
            className={inputCls}
            placeholder="https://corsproxy.io/?"
            value={f.proxy}
            onChange={(e) => setF({ ...f, proxy: e.target.value })}
          />
        </Field>
        <div className="flex gap-3">
          <Button onClick={() => onSave(f)}>💾 Save</Button>
          <Button variant="soft" onClick={onTest} disabled={loading}>
            {loading ? "Testing…" : "🔌 Test connection"}
          </Button>
        </div>
      </Card>
      <Card className="h-fit text-sm">
        <h3 className="mb-2 font-black">How it works 💡</h3>
        <ul className="space-y-2 text-slate-500">
          <li>• Panel speaks the standard SMM API v2 (PerfectPanel).</li>
          <li>
            • It POSTs <code className="rounded bg-pink-50 px-1">key</code>,{" "}
            <code className="rounded bg-pink-50 px-1">action</code> + params.
          </li>
          <li>• Actions used: services, balance, add, status.</li>
          <li>• Keys are stored only in your browser localStorage.</li>
        </ul>
      </Card>
    </div>
  );
}
