// Generic SMM Panel API client (PerfectPanel / "api/v2" standard)
// Works with most providers: JustAnotherPanel, SMMKings, Peakerr, etc.

export type ApiConfig = {
  endpoint: string; // e.g. https://provider.com/api/v2
  apiKey: string;
  proxy: string; // optional CORS proxy prefix
};

export type Service = {
  service: string | number;
  name: string;
  type: string;
  category: string;
  rate: string;
  min: string;
  max: string;
  refill?: boolean;
  cancel?: boolean;
};

export type Order = {
  id: string;
  service: string;
  link: string;
  quantity: number;
  charge: string;
  status: string;
  start_count?: string;
  remains?: string;
  created: number;
};

const CFG_KEY = "viralcute.apiconfig";

export const defaultConfig: ApiConfig = {
  endpoint: "",
  apiKey: "",
  proxy: "",
};

export function loadConfig(): ApiConfig {
  try {
    const raw = localStorage.getItem(CFG_KEY);
    if (raw) return { ...defaultConfig, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return defaultConfig;
}

export function saveConfig(cfg: ApiConfig) {
  localStorage.setItem(CFG_KEY, JSON.stringify(cfg));
}

export async function callApi<T = any>(
  cfg: ApiConfig,
  params: Record<string, string | number>,
): Promise<T> {
  if (!cfg.endpoint) throw new Error("No API endpoint configured. Open Settings ⚙️");
  const body = new URLSearchParams();
  body.append("key", cfg.apiKey);
  Object.entries(params).forEach(([k, v]) => body.append(k, String(v)));

  const url = (cfg.proxy || "") + cfg.endpoint;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
  });
  if (!res.ok) throw new Error(`Provider responded ${res.status}`);
  const data = await res.json();
  if (data && data.error) throw new Error(String(data.error));
  return data as T;
}

export const api = {
  services: (cfg: ApiConfig) => callApi<Service[]>(cfg, { action: "services" }),
  balance: (cfg: ApiConfig) =>
    callApi<{ balance: string; currency: string }>(cfg, { action: "balance" }),
  addOrder: (cfg: ApiConfig, p: Record<string, string | number>) =>
    callApi<{ order: number }>(cfg, { action: "add", ...p }),
  status: (cfg: ApiConfig, order: string | number) =>
    callApi<any>(cfg, { action: "status", order }),
};

// ---- local order history -------------------------------------------------
const ORD_KEY = "viralcute.orders";
export function loadOrders(): Order[] {
  try {
    return JSON.parse(localStorage.getItem(ORD_KEY) || "[]");
  } catch {
    return [];
  }
}
export function saveOrders(o: Order[]) {
  localStorage.setItem(ORD_KEY, JSON.stringify(o));
}

// ---- demo data (used when no API is configured) --------------------------
export const demoServices: Service[] = [
  { service: 101, name: "Instagram Followers 💖 Real & Cute", type: "Default", category: "Instagram", rate: "0.85", min: "50", max: "100000", refill: true },
  { service: 102, name: "Instagram Likes ✨ Instant", type: "Default", category: "Instagram", rate: "0.32", min: "20", max: "50000" },
  { service: 103, name: "Instagram Reels Views 🎬", type: "Default", category: "Instagram", rate: "0.05", min: "100", max: "1000000" },
  { service: 201, name: "TikTok Followers 🌸 HQ", type: "Default", category: "TikTok", rate: "1.10", min: "100", max: "200000", refill: true },
  { service: 202, name: "TikTok Likes 💫 Fast", type: "Default", category: "TikTok", rate: "0.18", min: "50", max: "80000" },
  { service: 203, name: "TikTok Views 🚀 Super Speed", type: "Default", category: "TikTok", rate: "0.02", min: "500", max: "5000000" },
  { service: 301, name: "YouTube Subscribers 🎀 Non-drop", type: "Default", category: "YouTube", rate: "4.50", min: "50", max: "20000", refill: true },
  { service: 302, name: "YouTube Watch Hours ⏱️", type: "Default", category: "YouTube", rate: "9.90", min: "100", max: "4000" },
  { service: 401, name: "Twitter / X Followers 🐦", type: "Default", category: "Twitter / X", rate: "2.40", min: "100", max: "50000" },
  { service: 501, name: "Telegram Members 💌", type: "Default", category: "Telegram", rate: "1.75", min: "100", max: "100000" },
  { service: 601, name: "Spotify Plays 🎧", type: "Default", category: "Spotify", rate: "0.60", min: "1000", max: "1000000" },
  { service: 701, name: "Facebook Page Likes 👍", type: "Default", category: "Facebook", rate: "1.30", min: "100", max: "60000" },
];
